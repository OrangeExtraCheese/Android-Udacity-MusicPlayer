package tomaszmarzec.udacity.android.musicplayer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import static tomaszmarzec.udacity.android.musicplayer.Database.sArtistList;

public class BrowseArtistsActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_artists);



        ArtistAdapter artistAdapter = new ArtistAdapter(this, sArtistList);

        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(artistAdapter);
    }








}
