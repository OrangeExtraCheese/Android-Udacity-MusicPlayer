package tomaszmarzec.udacity.android.musicplayer;

import android.os.Parcel;
import android.os.Parcelable;

public class Song implements  Parcelable
{
    private String mSongTitle, mArtist, mGenre, mAlbum, mMusicArtFileName;

    public Song(String songTitle, String artist, String genre, String album, String musicArtFileName)
    {
        mSongTitle = songTitle;
        mArtist = artist;
        mGenre = genre;
        mAlbum = album;
        mMusicArtFileName = musicArtFileName;
    }


    //This constructor is used in Album class for the purpose of creating Song objects in loop, I did'n know how to solve it in other way
    public Song()
    {

    }

    public String getSongTitle() {
        return mSongTitle;
    }

    public String getArtist() {
        return mArtist;
    }

    public String getGenre() {
        return mGenre;
    }

    public String getAlbum() {
        return mAlbum;
    }

    public String getMusicArtFileName() {
        return mMusicArtFileName;
    }

     /*
    FOUND IN QUESTION:
    How can I make my custom objects Parcelable?. Stack Overflow.
    Retrieved 21 July 2018, from https://stackoverflow.com/questions/7181526/how-can-i-make-my-custom-objects-parcelable
    CODE FROM:
    Parcelable - How to do that in Android  Techdroid. (2010).
    Retrieved 21 July 2018, from http://techdroid.kbeanie.com/2010/06/parcelable-how-to-do-that-in-android.html*/

    public Song(Parcel in){
        String[] data = new String[5];

        in.readStringArray(data);
        // the order needs to be the same as in writeToParcel() method
        mSongTitle = data[0];
        mArtist = data[1];
        mGenre = data[2];
        mAlbum = data[3];
        mMusicArtFileName = data[4];

    }

    @Override
    public int describeContents(){
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeStringArray(new String[]
                {
                        this.getSongTitle(),
                        this.getArtist(),
                        this.getGenre(),
                        this.getAlbum(),
                        this.getMusicArtFileName()
                });
    }
    public static final Parcelable.Creator CREATOR = new Parcelable.Creator()
    {
        @Override
        public Song createFromParcel(Parcel in)
        {
            return new Song(in);
        }

        @Override
        public Song[] newArray(int size) {
            return new Song[size];
        }
    };
}
