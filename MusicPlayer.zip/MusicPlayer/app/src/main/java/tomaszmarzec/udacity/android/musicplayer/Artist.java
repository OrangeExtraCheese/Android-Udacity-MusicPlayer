package tomaszmarzec.udacity.android.musicplayer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class Artist
{
    private String mName, mCountry, mGenre, mMusicArtFileName;

    private ArrayList<Album> mAlbumsList = new ArrayList<>();
    private ArrayList<Song> mStandaloneSongsList;
    private ArrayList<Song> mAllSongs;

    public Artist(String name, String country, String genre)
    {
        mName = name;
        mCountry = country;
        mGenre = genre;

        mMusicArtFileName = (mName).toLowerCase().replaceAll("\\s","");
    }

    public Artist(String name,  String genre)
    {
        mName = name;
        mCountry = "data update required";
        mGenre = genre;

        mMusicArtFileName = (mName).toLowerCase().replaceAll("\\s","");
    }


    public void addAlbum(String albumTitle, String releaseYear, String albumGenre)
    {
        Album albumToAdd = new Album(albumTitle, releaseYear, albumGenre, mName);
        albumToAdd.setArtist(mName);
        mAlbumsList.add(albumToAdd);
    }

    public void addSingleSong(String songTitle, String musicArtFileName)
    {
        Song songToAdd = new Song(songTitle, mName, mGenre, "single song", musicArtFileName);
        mStandaloneSongsList.add(songToAdd);
        Database.addToAllSongsList(songToAdd);
    }

    public void setmCountry(String mCountry) {
        this.mCountry = mCountry;
    }

    public String getName() {
        return mName;
    }

    public String getGenre() {
        return mGenre;
    }

    public ArrayList<Album> getAlbumsList() {
        return mAlbumsList;
    }

    public String getMusicArtFilename()
    {
        return mMusicArtFileName;
    }

    public void addSongsToAlbum(String albumTitle, String[] songTitles)
    {
        Song songToAdd = new Song();
        for(Album album:mAlbumsList)
        {
            if(album.getAlbumTitle().equals(albumTitle))
                album.insertSongs(songTitles);
        }
    }

    public ArrayList<Song> getArtistSongs()
    {
        ArrayList<Song> allArtistSongs = new ArrayList<>();
        allArtistSongs.addAll(mStandaloneSongsList);

        for(Album album:mAlbumsList)
        {
            allArtistSongs.addAll(album.getAlbumSongs());
        }

        Collections.shuffle(allArtistSongs);
        return allArtistSongs;
    }
}
