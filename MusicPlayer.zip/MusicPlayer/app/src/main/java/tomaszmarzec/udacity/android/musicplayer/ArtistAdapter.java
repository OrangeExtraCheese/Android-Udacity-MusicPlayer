package tomaszmarzec.udacity.android.musicplayer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ArtistAdapter extends ArrayAdapter<Artist>
{

    private Context mActivityContext;

    public ArtistAdapter(Activity context, ArrayList<Artist> array)

    {

        super(context,0,  array);
        mActivityContext = context;
    }

    private View.OnClickListener createBrowseAlbumsListener(final Class activityToOpen, final ArrayList<Album> artistAlbumsArray)
    {
        return new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(mActivityContext, activityToOpen);

                i.putExtra("array", artistAlbumsArray);
                mActivityContext.startActivity(i);
            }
        };
    }

    private View.OnClickListener createBrowseSongsListener(final Class activityToOpen, final ArrayList<Song> artistAlbumsArray)
    {
        return new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(mActivityContext, activityToOpen);

                i.putExtra("array", artistAlbumsArray);
                mActivityContext.startActivity(i);
            }
        };
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
    {
        if(convertView == null)
        {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.music_list_item, parent, false);
        }

        Artist artist = getItem(position);

        ImageView picture = convertView.findViewById(R.id.music_art);
        picture.setMaxWidth((int)(picture.getWidth()*2));
        picture.setImageResource(matchImage(artist.getMusicArtFilename()));

        TextView artistName = convertView.findViewById(R.id.text1);
        artistName.setText(artist.getName());
        TextView artistGenre = convertView.findViewById(R.id.text2);
        artistGenre.setText(artist.getGenre());

        Button browseAlbums = convertView.findViewById(R.id.first_button);
        browseAlbums.setText("Browse albums");
        browseAlbums.setOnClickListener(createBrowseAlbumsListener(BrowseAlbumsActivity.class, artist.getAlbumsList()));

        Button browseSongs = convertView.findViewById(R.id.second_button);
        browseSongs.setText("Browse songs");
        browseSongs.setOnClickListener(createBrowseSongsListener(BrowseSongsActivity.class, artist.getArtistSongs()));

        return convertView;

    }

    private int matchImage(String imageName)
    {
        return mActivityContext.getResources().getIdentifier(imageName, "drawable", "tomaszmarzec.udacity.android.musicplayer");
    }
}
