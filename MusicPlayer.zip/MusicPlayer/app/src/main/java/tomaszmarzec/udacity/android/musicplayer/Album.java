package tomaszmarzec.udacity.android.musicplayer;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;


public class Album implements Parcelable
{
    private String mAlbumTitle, mAlbumGenre, mReleaseYear, mArtist, mMusicArtFileName;
    private ArrayList<Song> albumSongs = new ArrayList<>();

   public void insertSongs(String[] songTitles)
   {
       /* If I write this in following way:

       Song songToAdd;
       for(String title:songTitles)
           songToAdd = new Song(title, mArtist, mAlbumGenre, mAlbumTitle);
           albumSongs.add(songToAdd);
           Database.addToAllSongsList(songToAdd);

       Then I get an error that songToAdd might not have been initialized, so to avoid it i created additional constructor in song class,
       taking no parameters.
       */

       Song songToAdd = new Song();
       for(String title:songTitles)
       {
           songToAdd = new Song(title, mArtist, mAlbumGenre, mAlbumTitle, mMusicArtFileName);
           albumSongs.add(songToAdd);
           Database.addToAllSongsList(songToAdd);
       }

   }

    public String getAlbumTitle() {
        return mAlbumTitle;
    }

    public ArrayList<Song> getAlbumSongs() {
        return albumSongs;
    }

    public void setArtist(String artist) {
        mArtist = artist;
    }

/*
    public void setMusicArtFileName(String musicArt) {
        mMusicArtFileName = musicArt;
    }
*/

    public String getMusicArtFilename()
    {
        return mMusicArtFileName;
    }

    public Album(String albumTitle, String releaseYear, String albumGenre, String artist)
    {
        mAlbumTitle = albumTitle;
        mReleaseYear = releaseYear;
        mAlbumGenre = albumGenre;
        mArtist = artist;

        mMusicArtFileName = (mArtist+mAlbumTitle).toLowerCase().replaceAll("\\s","");
    }

    /* Solution to implementing custom ArrayList class parcelable from this question on StackOverflow:
       https://stackoverflow.com/questions/22446359/android-class-parcelable-with-arraylist
       by Miro Markaravanes
     */

    public Album(Parcel parcel)
    {
        // the order needs to be the same as parcel writeToParcel() method
        mAlbumTitle = parcel.readString();
        mArtist = parcel.readString();
        mAlbumGenre = parcel.readString();
        mReleaseYear = parcel.readString();
        mMusicArtFileName = parcel.readString();
        albumSongs = parcel.readArrayList(Song.class.getClassLoader());
    }

    @Override
    public int describeContents(){
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
                        dest.writeString(mAlbumTitle);
                        dest.writeString(mArtist);
                        dest.writeString(mAlbumGenre);
                        dest.writeString(mReleaseYear);
                        dest.writeString(mMusicArtFileName);
                        dest.writeList(albumSongs);
    }
    public static final Parcelable.Creator CREATOR = new Parcelable.Creator()
    {
        @Override
        public Album createFromParcel(Parcel source)
        {
            return new Album(source);
        }

        @Override
        public Album[] newArray(int size) {
            return new Album[size];
        }
    };


}



