package tomaszmarzec.udacity.android.musicplayer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity
{

/*    To shortly explain how this app functions: Every artist, music album and song is an object. There are three classes in which music is organised: Album, Artist and Song
    Artist possesses member variable mAlbumsList, an ArrayList<Album> of albums. Album similarly posses mAlbumSongs, an ArrayList<Song> of songs. So, Song objects are organised in Album objects,
    and Album objects are organised in Artist objects. There are three custom adapter classes, for each of mentioned three classes.
    */
    @OnClick({R.id.browse_artists})
    protected void open_browse_artists()
    {
        Intent i =new Intent(this, BrowseArtistsActivity.class);
        startActivity(i);
    }

    @OnClick({R.id.browse_albums})
    protected void open_browse_albums()
    {
        Intent i =new Intent(this, BrowseAlbumsActivity.class);
        startActivity(i);
    }

    @OnClick({R.id.browse_songs})
    protected void open_browse_songs()
    {
        Intent i =new Intent(this, BrowseSongsActivity.class);
        startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Database.addArtists();
        Database.addMusic();


        ButterKnife.bind(this);
    }
}
