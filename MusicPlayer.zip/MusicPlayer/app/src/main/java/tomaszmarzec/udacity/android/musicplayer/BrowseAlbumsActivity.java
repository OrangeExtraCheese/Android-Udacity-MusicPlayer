package tomaszmarzec.udacity.android.musicplayer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class BrowseAlbumsActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_albums);

        Intent i = getIntent();
        ArrayList<Album> albumsToDisplay;

        if(i.getExtras()!=null)
        {
            Bundle extras = i.getExtras();
            albumsToDisplay =  extras.getParcelableArrayList("array");

        }
        else
            albumsToDisplay = Database.getAllAlbumsList();



        AlbumAdapter albumAdapter = new AlbumAdapter(this, albumsToDisplay);

        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(albumAdapter);
    }
}
