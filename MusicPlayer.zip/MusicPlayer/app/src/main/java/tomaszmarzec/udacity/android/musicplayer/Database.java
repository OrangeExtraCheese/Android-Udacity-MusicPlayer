package tomaszmarzec.udacity.android.musicplayer;

import java.util.ArrayList;
import java.util.Collections;

public class Database
{
   static ArrayList<Artist> sArtistList = new ArrayList<>();
    private static ArrayList<Song> sAllSongsList = new ArrayList<>();


    public static void addToAllSongsList(Song newSong)
    {
        for(Song song:sAllSongsList)
        if(song.getArtist().equals(newSong.getArtist()))
            break;
        sAllSongsList.add(newSong);
    }

    /* Method taking album data as info, and then iterating through artist to check if artist of new album is already in array of artists.
       If yes, method addAlbum of Album class is called to add album to artist, and then method addSongsToAlbum to add songs to new album. If no, new artist is added
       array of artists.
     */
    public static void addNewAlbum(String artistName, String albumTitle, String releaseYear, String albumGenre, String[] songTitles)
    {
        for(Artist artist:sArtistList)
        {
            if(artist.getName().equals(artistName))
            {
                artist.addAlbum(albumTitle, releaseYear, albumGenre);
                artist.addSongsToAlbum(albumTitle, songTitles);
                return;
            }
        }
        //Artist added this way needs to be updated later - member variable country takes default value of "data update required" and genre member variable may be inaccurate because it takes value from album.
        Artist newArtist = new Artist(artistName, albumGenre);
        newArtist.addAlbum(albumTitle, releaseYear, albumGenre);
        newArtist.addSongsToAlbum(albumTitle, songTitles);
        sArtistList.add(newArtist);
    }


    //This method can be used to add song to artist while omitting album. If user buys single song, or song has been released as a single, then this songs belongs to artist, but not a particular album.
    public static void addStandAloneSong(String artistName, String songTitle, String musicArtFileName)
    {
        for(Artist artist:sArtistList)
        {
            if(artist.getName().equals(artistName))
                artist.addSingleSong(songTitle, musicArtFileName);
        }

    }

    public static void addSongsToAlbum(String artistName, String albumTitle ,String[] songTitles)
    {
        for(Artist artist:sArtistList)
        {
            if(artist.getName().equals(artistName))
                for(Album album:artist.getAlbumsList())
                    if(album.getAlbumTitle().equals(albumTitle))
                        album.insertSongs(songTitles);
        }
    }

    // In real application, I think, this method would probably be replaced with method querying database system, it is a provisional method to fill app with example artists.
    public static void addArtists()
    {
        sArtistList.add(new Artist("Judas Priest", "UK", "heavy metal/rock"));
        sArtistList.add(new Artist("Florence And The Machine", "UK", "indie pop"));
        sArtistList.add(new Artist("Diana Ross", "USA", "R&B/soul"));
    }


    /*Like a previous one, this is a provisional method which adds new albums (along with songs for this albums), to artists. It is called from
      MainActivity when app starts. In real production app, this method probably would replaced with method connecting to database system.
     */
    public static void addMusic()
    {
        String[] songsScreamingForVengeance = new String[]{"The Hellion","Electric Eye","Riding on the Wind","Bloodstone",	"(Take These) Chains",	"Pain and Pleasure", "Screaming for Vengeance", "You've Got Another Thing Comin'", "Fever", "Devil's Child"};
        addNewAlbum("Judas Priest", "Screaming For Vengeance", "1982", "heavy metal", songsScreamingForVengeance);
        String[] songsPainkiller = new String[]{"Painkiller","Hell Patrol","All Guns Blazing","Leather Rebel","Metal Meltdown","Night Crawler","A Touch of Evil","Battle Hymn","One Shot at Glory"};
        addNewAlbum("Judas Priest", "Painkiller", "1990", "heavy/speed metal", songsPainkiller);
        String[] songsCeremonials = new String[]{"Only If for a Night", "Shake It Out", "What the Water Gave Me", "Never Let Me Go", "Breaking Down", "Lover to Lover", "Seven Devils", "Heartlines", "Spectrum", "All This and Heaven Too", "Leave My Body"};
        addNewAlbum("Florence And The Machine", "Ceremonials", "2011", "indie pop", songsCeremonials);
        String[] songsHighAsHope = new String[]{"June", "Hunger", "South London Forever", "Big God", "Sky Full of Song", "Grace", "Patricia", "The End of Love", "No Choir"};
        addNewAlbum("Florence And The Machine", "High As Hope", "2018", "indie pop", songsHighAsHope );
        String[] songsDianaRoss = new String[]{"Reach Out and Touch (Somebody's Hand)" , "Now That There's You" , "You're All I Need to Get By" , "These Things Will Keep Me Loving You" , "Ain't No Mountain High Enough" , "Something on My Mind" , "I Wouldn't Change the Man He Is" , "Keep an Eye" , "Where There Was Darkness", "Can't It Wait Until Tomorrow" , "Dark Side of the World"};
        addNewAlbum("Diana Ross", "Diana Ross", "1980", "R&B/soul", songsDianaRoss );
        String[] songsSurrender = new String[]{"Painkiller"};
        addNewAlbum("Diana Ross", "Surrender", "1971", "R&B/soul", songsSurrender);

    }

    public static ArrayList<Album> getAllAlbumsList()
    {
        ArrayList<Album> albumsToSend = new ArrayList<>();
        for(Artist artist:sArtistList)
        {
            albumsToSend.addAll(artist.getAlbumsList());
        }

        return albumsToSend;
    }

    public static ArrayList<Song> getAllSongsList()
    {
        ArrayList<Album> allAlbums = getAllAlbumsList();
        ArrayList<Song> allSongsList = new ArrayList<>();
        for(Album album:allAlbums)
        {
            allSongsList.addAll(album.getAlbumSongs());
        }

        Collections.shuffle(allSongsList);
        return allSongsList;
    }


}
