package tomaszmarzec.udacity.android.musicplayer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class BrowseSongsActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_songs);

        Intent i = getIntent();
        ArrayList<Song> songsToDisplay;

        if(i.getExtras()!=null)
        {
            Bundle extras = i.getExtras();
            songsToDisplay =  extras.getParcelableArrayList("array");

        }
        else
            songsToDisplay = Database.getAllSongsList();

        SongAdapter songAdapter = new SongAdapter(this, songsToDisplay);

        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(songAdapter);

    }


}
