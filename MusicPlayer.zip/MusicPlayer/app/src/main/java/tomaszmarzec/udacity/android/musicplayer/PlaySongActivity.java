package tomaszmarzec.udacity.android.musicplayer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.BindView;
import butterknife.OnClick;

public class PlaySongActivity extends AppCompatActivity
{
    @BindView(R.id.music_art) ImageView musicArt;
    @BindView(R.id.song_title) TextView songTitle;
  /*  @BindView(R.id.previous_song_button) ImageButton previousSongButton;
    @BindView(R.id.next_song_button) ImageButton nextSongButton;*/

   @OnClick({R.id.previous_song_button})
   protected void playPreviousSong()
   {
       if(currentSongPosition-1 >= 0)
       {
           currentSongPosition--;
           playSong(songsToPlay.get(currentSongPosition));
       }
   }

    @OnClick({R.id.next_song_button})
    protected void playNextSong()
    {
        if(currentSongPosition+1 < songsToPlay.size())
        {
            currentSongPosition++;
            playSong(songsToPlay.get(currentSongPosition));
        }
    }

    ArrayList<Song> songsToPlay;
    int currentSongPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_song);

        Intent i = getIntent();

        Song songToPlay = i.getParcelableExtra("songToPlay");
        songsToPlay = i.getParcelableArrayListExtra("array");
        currentSongPosition =  i.getIntExtra("songNumber", 0);

        playSong(songToPlay);
    }

    private void playSong(Song song)
    {
        ButterKnife.bind(this);
        songTitle.setText(song.getSongTitle());
        // Name of file containg music art, of the type of String, is converted to resource identifier
        musicArt.setImageResource(getResources().getIdentifier(song.getMusicArtFileName(), "drawable", "tomaszmarzec.udacity.android.musicplayer"));
    }
}
